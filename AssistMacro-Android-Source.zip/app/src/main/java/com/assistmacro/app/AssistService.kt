package com.assistmacro.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.View
import android.view.Window
import android.view.WindowManager.LayoutParams

class AssistService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var menu: View? = null
    private var bubbleParams: LayoutParams? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        remove(menu); remove(bubble)
        instance = null
        super.onDestroy()
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else LayoutParams.TYPE_PHONE

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "●"
            textSize = 29f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(20, 132, 255))
            elevation = 12f
        }
        bubble = b
        val p = LayoutParams(62, 62, overlayType(),
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            x = 18; y = 0
        }
        bubbleParams = p
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragged = false
        b.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = p.x; startY = p.y; dragged = false
                    true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) dragged = true
                    if (dragged) {
                        p.x = (startX - dx).coerceAtLeast(0)
                        p.y = startY + dy
                        try { wm.updateViewLayout(b, p) } catch (_: Exception) {}
                    }
                    true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    if (!dragged) toggleMenu()
                    true
                }
                else -> true
            }
        }
        wm.addView(b, p)
    }

    private fun toggleMenu() {
        if (menu != null) { remove(menu); menu = null; return }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(Color.rgb(35, 42, 55))
        }
        panel.addView(TextView(this).apply {
            text = "Assist Macro"; textSize = 18f; setTextColor(Color.WHITE)
            setPadding(4, 4, 4, 12)
        })
        addAction(panel, "الرئيسية") { performGlobalAction(GLOBAL_ACTION_HOME) }
        addAction(panel, "رجوع") { performGlobalAction(GLOBAL_ACTION_BACK) }
        addAction(panel, "التطبيقات الأخيرة") { performGlobalAction(GLOBAL_ACTION_RECENTS) }
        addAction(panel, "الإشعارات") { performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) }
        addAction(panel, "الإعدادات السريعة") { performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS) }
        if (Build.VERSION.SDK_INT >= 28) addAction(panel, "قفل الشاشة") {
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
        addAction(panel, "الإيماءات") {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        addAction(panel, "إغلاق القائمة") { remove(menu); menu = null }
        menu = panel
        val p = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
            overlayType(), LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            x = 88; y = 0
        }
        wm.addView(panel, p)
    }

    private fun addAction(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(54, 66, 86))
            setOnClickListener { action() }
        }
        parent.addView(button)
    }

    private fun remove(v: View?) {
        if (v != null) try { wm.removeView(v) } catch (_: Exception) {}
    }

    fun playSavedGesture() {
        val raw = getSharedPreferences("assist_macro", MODE_PRIVATE).getString("gesture", null) ?: return
        val size = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(size)
        val path = Path()
        val coords = raw.split(";").mapNotNull {
            val a = it.split(",")
            if (a.size != 2) null else {
                val x = a[0].toFloatOrNull(); val y = a[1].toFloatOrNull()
                if (x == null || y == null) null else (x * size.widthPixels) to (y * size.heightPixels)
            }
        }
        if (coords.isEmpty()) return
        path.moveTo(coords.first().first, coords.first().second)
        coords.drop(1).forEach { path.lineTo(it.first, it.second) }
        val duration = (coords.size * 12L).coerceIn(120L, 2500L)
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    companion object { @Volatile var instance: AssistService? = null }
}
