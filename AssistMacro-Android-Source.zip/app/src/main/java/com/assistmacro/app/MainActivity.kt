package com.assistmacro.app

import android.app.Activity
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var pad: GesturePad
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
            setBackgroundColor(Color.rgb(246, 248, 252))
        }
        root.addView(TextView(this).apply {
            text = "Assist Macro"
            textSize = 27f
            setTextColor(Color.rgb(25, 35, 55))
        })
        root.addView(TextView(this).apply {
            text = "سجّل حركة بإصبعك داخل المساحة، احفظها، ثم شغّلها من الزر العائم."
            textSize = 15f
            setPadding(0, 12, 0, 16)
        })
        status = TextView(this).apply { text = "جاهز للتسجيل"; textSize = 14f }
        root.addView(status)
        pad = GesturePad(this)
        root.addView(pad, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { setMargins(0, 14, 0, 14) })

        val save = Button(this).apply {
            text = "حفظ الإيماءة"
            setOnClickListener {
                if (!pad.hasGesture) {
                    Toast.makeText(this@MainActivity, "سجّل حركة أولاً", Toast.LENGTH_SHORT).show()
                } else {
                    getSharedPreferences("assist_macro", MODE_PRIVATE)
                        .edit().putString("gesture", pad.serialize()).apply()
                    status.text = "تم حفظ الإيماءة"
                    Toast.makeText(this@MainActivity, "تم الحفظ", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val play = Button(this).apply {
            text = "تشغيل الإيماءة المحفوظة"
            setOnClickListener {
                val service = AssistService.instance
                if (service == null) {
                    Toast.makeText(this@MainActivity, "فعّل Assist Macro من إعدادات إمكانية الوصول أولاً", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } else {
                    service.playSavedGesture()
                    status.text = "جارٍ تشغيل الإيماءة"
                }
            }
        }
        val access = Button(this).apply {
            text = "تفعيل خدمة Assist Macro"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(save)
        root.addView(play)
        root.addView(access)
        setContentView(root)
    }

    private class GesturePad(ctx: android.content.Context) : View(ctx) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(20, 132, 255); strokeWidth = 9f
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(20, 132, 255) }
        private val path = Path()
        private val points = mutableListOf<Pair<Float, Float>>()
        var hasGesture = false
            private set

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.WHITE)
            val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.LTGRAY; style = Paint.Style.STROKE; strokeWidth = 2f
            }
            canvas.drawRect(2f, 2f, width - 2f, height - 2f, border)
            canvas.drawText("ارسم الحركة هنا", 24f, 42f,
                Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY; textSize = 28f })
            canvas.drawPath(path, line)
            if (points.isNotEmpty()) {
                val p = points.last()
                canvas.drawCircle(p.first, p.second, 13f, dot)
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    points.clear(); path.reset()
                    points.add(event.x to event.y)
                    path.moveTo(event.x, event.y); hasGesture = true; invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    for (i in 0 until event.historySize) {
                        val x = event.getHistoricalX(i); val y = event.getHistoricalY(i)
                        points.add(x to y); path.lineTo(x, y)
                    }
                    points.add(event.x to event.y); path.lineTo(event.x, event.y)
                    invalidate(); return true
                }
                MotionEvent.ACTION_UP -> {
                    points.add(event.x to event.y); path.lineTo(event.x, event.y)
                    invalidate(); return true
                }
            }
            return true
        }

        fun serialize(): String {
            val location = IntArray(2)
            getLocationOnScreen(location)
            val wm = context.getSystemService(android.content.Context.WINDOW_SERVICE) as android.view.WindowManager
            val metrics = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            return points.joinToString(";") {
                "${(location[0] + it.first) / metrics.widthPixels}," +
                    "${(location[1] + it.second) / metrics.heightPixels}"
            }
        }
    }
}
