# Assist Macro (prototype)

Android Studio project for an AssistiveTouch-inspired floating menu.

## Included in this prototype
- Floating blue accessibility overlay button that can be dragged.
- Menu shortcuts: Home, Back, Recents, Notifications, Quick Settings, and Lock screen (Android 9+).
- In-app gesture drawing, saving, and replay using `AccessibilityService.dispatchGesture`.

## Important limitations
- Gesture recording currently happens inside the app's drawing area, not by capturing arbitrary touches across other apps.
- Replaying a saved gesture uses normalized coordinates against the current display size; test carefully.
- Some actions depend on Android version and device manufacturer.
- This is an independent Android implementation, not Apple's software or an exact copy.

## Build an APK with GitHub Actions
1. Upload the contents of this project folder to a GitHub repository (the `.github/workflows/build.yml` file must be included).
2. Open the repository's **Actions** tab.
3. Run **Build Assist Macro APK**, or push a commit to `main`/`master`.
4. Open the completed workflow run and download the `AssistMacro-debug-apk` artifact.
5. Extract `app-debug.apk` and install it on your Android phone.

## Build locally
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build APK(s)**.

To use the floating menu, open Assist Macro, tap "تفعيل خدمة Assist Macro", and enable the service in Android Accessibility settings.
